# 06 - FRONT SPEC - Producto desacoplado laboral-front

Reutilizar design system de pensiones.

## Rutas
/laboral -> landing producto + chat
/laboral/chat/:id -> chat
/mis-documentos -> lista docs laborales

## Componentes
1. Selector de producto en panel: Agregar card "Asistente Laboral - Consultas y Documentos" con badge NUEVO
2. Chat:
   - Mismo componente que pensiones pero system prompt diferente
   - Quick replies iniciales B2C (chips): Me despidieron, No me pagaron finiquito, Sufro acoso Ley Karin, No me bajaron a 40h, Estoy con licencia y me despidieron
   - Si backend retorna faltan_datos, renderizar formulario inline (ej: input sueldo, datepicker ingreso) en vez de pedir por texto. Al enviar formulario, reenvía mensaje al chat automáticamente.
   - Sidebar derecho desktop: "Base legal usada" con lista de artículos + url_bcn (transparencia, genera confianza)
3. CTA Documento:
   Cuando backend retorna cta_documentos, mostrar cards: "Generar Reclamo DT - 3 créditos" con botón
   Al click, abrir modal con formulario schema (reutilizar componente de pensiones). Validar RUT chileno con módulo.
4. Visor DOCX/PDF: mismo que pensiones
5. Créditos: mismo hook useCredits()

## Estados vacíos
Si sin créditos, mostrar paywall existente.

## Analytics
Eventos: laboral_chat_started, laboral_datos_faltantes, laboral_documento_generado {tipo}, laboral_calculo_finiquito
