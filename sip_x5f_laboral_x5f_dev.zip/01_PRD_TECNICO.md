# 01 - PRD TÉCNICO - MÓDULO LABORAL B2C

## Objetivo
Crear producto `laboral` para trabajador final chileno. El usuario escribe su problema en lenguaje natural y obtiene: diagnóstico legal citando BCN, cálculo estimado y generación de documento legal listo para presentar.

## Principios
- B2C lenguaje simple, 0 abogadés. Explicar como a un amigo.
- 100% grounded: Toda respuesta debe citar Artículo + Ley + URL BCN. Si no hay contexto, responder "No encuentro base legal vigente en BCN".
- Conversión: Cada consulta termina en CTA de documento (3 créditos) o cálculo.

## User Flow MVP
1. Usuario entra a /laboral, ve quick replies: ["Me despidieron", "No me pagaron finiquito", "Sufro acoso Ley Karin", "No me bajaron a 40h", "Estoy con licencia y me despidieron"]
2. Escribe: "Me despidieron ayer, llevaba 2 años, me debían cotizaciones"
3. Backend clasifica: tipo=DESPIDO_INJUSTIFICADO, extrae datos, detecta faltan_datos=[sueldo, fecha_ingreso]
4. Front muestra formulario inline para sueldo y fecha ingreso (no preguntar por chat)
5. Con datos completos, RAG busca en colección chile_laboral (top_k 8) filtrando por materia=despido + siempre Art 162 si hay deuda cotizaciones
6. LLM responde con estructura de 5 partes (resumen, qué dice la ley, cuánto te toca, qué hacer, CTA documento)
7. Usuario hace clic en "Generar Reclamo DT" -> POST /v1/laboral/document/generate -> cobra 3 créditos -> genera DOCX/PDF y lo deja en panel /mis-documentos
8. Todo queda guardado en RAG por user_id para historial.

## MVP Scope - Sprint 1
Solo 4 flujos que cubren 80% consultas Chile:
1. Despido Injustificado 161 + Nulidad Ley Bustos 162
2. Autodespido 171
3. Denuncia Ley Karin 21.643
4. Reclamo 40 horas 21.561

Fuera de MVP: demandas tutela laboral completa, cálculo 90 UF exacto con reajustes IPC, comparendo SUSESO, fuero maternal.

## Criterios de Aceptación
- CA1: Si texto contiene "licencia" + "despido", respuesta DEBE citar Art 162 y explicar nulidad despido.
- CA2: Si texto contiene "acoso, me gritan, me hostigan", DEBE citar Ley 21.643 Art 2 inc 2 y 211-A.
- CA3: Si texto contiene "40 horas, horas extra", DEBE citar Art 22, 32 CT y que horas extra son voluntarias y con pacto escrito.
- CA4: Cada respuesta debe tener al menos 1 cita con url_bcn.
- CA5: Si faltan datos críticos (sueldo, fecha), NO generar cálculo final, pedir datos.
