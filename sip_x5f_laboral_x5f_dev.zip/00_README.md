# SIP - Módulo Laboral B2C
Producto desacoplado que usa API CORE existente.

Stack actual: API CORE (auth, créditos, pagos, RAG, ingesta) + front desacoplados + router LLM + panel user + chat.

Este pack contiene todo para implementar el nuevo producto: laboral.

## Contenido
01_PRD_TECNICO.md -> Requerimiento funcional
02_INGESTA_BCN.md -> Qué ingerir y cómo
03_API_SPEC.md -> Endpoints nuevos
04_SCHEMAS_DOCUMENTOS.json -> 4 documentos MVP + templates
05_PROMPTS_SYSTEM.md -> Prompts del router
06_FRONT_SPEC.md -> Qué construir en el front
