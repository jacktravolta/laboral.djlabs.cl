# 02 - INGESTA BCN - Colección chile_laboral

## Vector Store
Crear nueva colección: chile_laboral
Embedding: mismo que pensiones (mantener compatibilidad)
Chunk size: 800 tokens, overlap 150. Preservar artículo completo, no cortar artículos a la mitad.

## Fuentes BCN a Ingestar (en orden prioridad)
1. Código del Trabajo - Ley actualizada (https://www.bcn.cl/leychile/navegar?idNorma=207436)
   Extraer por artículos. Guardar texto íntegro Art 7-13, 21-40bis, 159-171, 184, 211-A a 211-E.
2. Ley 21.561 - 40 Horas (idNorma 1193423)
3. Ley 21.643 - Ley Karin (idNorma 1200212)
4. Ley 21.645 - Conciliación
5. Ley 19.728 Seguro Cesantía (para finiquito)
6. Dictámenes DT - Filtrar últimos 24 meses con tags: despido, jornada, acoso, feriado. Ingestar con resumen.

## Metadatos obligatorios por chunk
{
  "ley": "Código del Trabajo | Ley 21.561 | Ley 21.643",
  "articulo": "Art 168 | Art 2 inc 2",
  "materia": ["despido", "jornada", "acoso", "remuneracion", "fuero", "contrato", "licencia"],
  "vigencia": "2026-11-05",
  "url_bcn": "https://...",
  "tipo": "articulo | dictamen | reglamento"
}

## Filtros RAG
Siempre filtrar por vigencia vigente. Si materia = despido, forzar incluir Art 162, 168, 169. Si materia = acoso, forzar 211-A a 211-E.

## Job de actualización
Cron diario 04:00 AM CL - Revisar BCN si hay actualización Código del Trabajo. Re-ingerir solo artículos modificados.
