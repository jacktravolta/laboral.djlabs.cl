# 03 - API SPEC - Nuevos Endpoints (misma API CORE)

Usar misma autenticación JWT y lógica de créditos.

### 1. Clasificador
POST /v1/laboral/classify
Auth: Bearer
Body: { "texto": "Me despidieron estando con licencia..." }
Response: {
  "tipo": "DESPIDO_INJUSTIFICADO",
  "confianza": 0.92,
  "datos_extraidos": { "fecha_ingreso": null, "sueldo": null, "con_licencia": true },
  "faltan_datos": ["fecha_ingreso", "sueldo", "fecha_despido"],
  "materias_rag": ["despido", "licencia"]
}

### 2. Chat Laboral (consume 1 crédito)
POST /v1/laboral/chat
Body: { "mensaje": "...", "user_id": "...", "conversacion_id": "..." }
Lógica interna:
- Llama a /classify
- Si faltan_datos -> responde con quick form (no consume RAG)
- Si datos ok -> RAG query colección chile_laboral con filtro materias_rag, top_k 8 -> inyecta contexto -> llama router LLM con system_laboral_b2c_v1
- Guarda en RAG historial
Response: { "respuesta": "markdown con citas", "citas": [{"articulo":"Art 162", "ley":"CT", "url_bcn":"..."}], "cta_documentos": ["reclamo_dt_despido","carta_autodespido"], "creditos_restantes": 12 }

### 3. Generación Documento (consume 3 créditos)
POST /v1/laboral/document/generate
Body: {
  "tipo_documento": "carta_autodespido | reclamo_dt_despido | denuncia_ley_karin | reclamo_40_horas",
  "datos": { ... schema del doc ... },
  "conversacion_id": "..."
}
Response: { "documento_id": "uuid", "url_docx": "s3://...", "url_pdf": "s3://...", "datos_para_plantilla": {...} }

### 4. Cálculo Finiquito
POST /v1/laboral/calculo/finiquito
Body: { "fecha_ingreso":"2022-01-10", "fecha_termino":"2024-11-04", "sueldo_base":850000, "vacaciones_pendientes":5, "causal":"161", "hay_deuda_cotizaciones": true }
Response: { "anios":2, "meses":9, "indemnizacion_anios": 1700000, "tope_90uf": 3500000, "sustitutiva_aviso":850000, "feriado_proporcional":250000, "recargo_art_168": "50%", "total_estimado": 3300000, "advertencia": "Cálculo estimado, no considera IPC ni comisiones" }

### Manejo de créditos
Reutilizar middleware existente. Si créditos < costo, retornar 402 con { "error":"sin_creditos", "packs": [...] }
